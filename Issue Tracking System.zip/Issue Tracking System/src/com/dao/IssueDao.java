package com.dao;

import java.sql.*;
import com.bean.IssueBean;
import com.dbcon.DBCon;

public class IssueDao 
{
    public static int raiseIssue(IssueBean isb)
    {
    	int status=0;
    	try{
			Connection con=DBCon.getConnection();
			int reportId=0;
			PreparedStatement pst=con.prepareStatement("select max(reportId) from issues");
			ResultSet rs = pst.executeQuery();
			
			if(rs.next())
			{
				reportId=rs.getInt(1);
				reportId++;
			}			
					PreparedStatement pstmt=con.prepareStatement("insert into issues values(?,?,?,?)");
					pstmt.setInt(1, reportId);
					pstmt.setString(2,isb.getTitle());
					pstmt.setString(3,isb.getCategory());
					pstmt.setString(4,isb.getDe());
					
					status = pstmt.executeUpdate();
    	}
    	catch(Exception ex)
    	{
			ex.printStackTrace();
		}
    	return status;
       }
}