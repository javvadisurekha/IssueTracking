package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dbcon.DBCon;

public class systemEngDao {

	public static boolean validate(String userid, String password, String utype) {	
			Connection con=DBCon.getConnection();
			PreparedStatement ps;
			try {
				ps = con.prepareStatement("select type from login where userid=? and password=?");
				ps.setString(1,userid);
				ps.setString(2,password);
				ResultSet rs=ps.executeQuery();
				if(rs.next()) {
					String s=rs.getString(1);
					   if(s.equalsIgnoreCase(utype) && utype.equalsIgnoreCase("system engineer"))
						{
					return true;
				}
						}
				}
			
			catch (SQLException e) 
			{	
				e.printStackTrace();
			}
			return false;
	}

}
