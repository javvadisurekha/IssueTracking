package com.dao;

import java.sql.*;
import com.dbcon.DBCon;
	
	public class EmployeeDao 
	{
public static boolean validate(String userid, String password, String utype) {	
				Connection con=DBCon.getConnection();
				PreparedStatement ps;
				try {
					ps = con.prepareStatement("select type from login where userid=? and password=?");
					ps.setString(1,userid);
					ps.setString(2,password);
					ResultSet rs=ps.executeQuery();
					if(rs.next()) {
						String s=rs.getString(1);
						   if(s.equalsIgnoreCase(utype) && utype.equalsIgnoreCase("employee"))
							{
						return true;
					}
							}
					}
				catch (SQLException e) 
				{	
					e.printStackTrace();
				}
				return false;
		}
	}