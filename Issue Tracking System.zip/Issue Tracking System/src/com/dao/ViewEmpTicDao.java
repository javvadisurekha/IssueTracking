package com.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.bean.IssueBean;
import com.dbcon.DBCon;

public class ViewEmpTicDao
{  
	public static List<IssueBean> getIssues(){
		List<IssueBean> list=new ArrayList<IssueBean>();
		
		try{
			Connection con=DBCon.getConnection();
		    Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from issues");
			while(rs.next()){
				IssueBean eb=new IssueBean();
				
				eb.setRepid(rs.getInt(1));
                eb.setTitle(rs.getString(2));
                eb.setCategory(rs.getString(3));
                eb.setDe(rs.getString(4));    
				list.add(eb);
			}
			con.close();
		}catch(Exception e){e.printStackTrace();}
		
		return list;
	}
	
	
}
