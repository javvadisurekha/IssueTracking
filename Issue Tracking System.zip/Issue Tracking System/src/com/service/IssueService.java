package com.service;

import com.bean.IssueBean;
import com.dao.IssueDao;

public class IssueService 
{   
	public static int status1=0;
	public static void getIssues(String title, String category, String de)
	{
		IssueBean ib = new IssueBean();
		ib.setTitle(title);
		ib.setCategory(category);
	    ib.setDe(de);	
	    status1 = IssueDao.raiseIssue(ib);
	}	
}