package com.controller;

import com.dao.*;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	static final Logger logger = Logger.getLogger(LoginServlet.class);
     @Override
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

    	 PropertyConfigurator.configure("G:\\sts workspace\\Issue Tracking System\\src\\log4j.properties");
 		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String utype = request.getParameter("utype").trim();
		String userid = request.getParameter("userid").trim();
		String password = request.getParameter("password").trim();
		
			if(AdminDao.validate(userid,password,utype))
				{				    	
					RequestDispatcher rd = request
							.getRequestDispatcher("admin.html");
					rd.forward(request, response);
					logger.info("Admin Logged in");
				} 				
			else if (EmployeeDao.validate(userid,password,utype))
				{
							RequestDispatcher rd = request
									.getRequestDispatcher("employee.html");
							rd.forward(request, response);
							logger.info("Employee Logged in");

				}	
				else if (systemEngDao.validate(userid,password,utype))
				{
						
							RequestDispatcher rd = request
									.getRequestDispatcher("systemEngineer.html");
							rd.forward(request, response);
							logger.info("System Engineer Logged in");

				}
				else {
					RequestDispatcher rd = request
					.getRequestDispatcher("index.html");
					rd.include(request, response);
					out.println("<center><font color='blue'>Invalid Credentials.Provide Valid details</center>");
					logger.error("Invalid Credentials");
					}
	}
}