package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.dbcon.DBCon;

@WebServlet("/Assign1")
public class Assign1 extends HttpServlet 
{
	static final Logger logger = Logger.getLogger(Assign1.class);
	static String prio;
	static int rid;
   @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		rid= AssignTicketServlet.reportId;
		
		 prio=request.getParameter("priority").trim();
		
		doPost(request, response);
		
		PrintWriter out = response.getWriter();
        response.setContentType("text/html");
        out.println("<html><body background=back.jpg>");
        out.println("<h1 style=\"text:align=center\">");
        out.println("Issue Assigned Successfully");
        out.println("</h1>");
        out.println("<a href =\"admin.html\" > Mypage </a>");
        out.println("</body></html>");
	}
   @Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		resp.setContentType("text/html"); 
		int rid1 = rid;
		String pri = prio;

		 PropertyConfigurator.configure("G:\\sts workspace\\Issue Tracking System\\src\\log4j.properties");
	 		
		  try{  
			  Connection connection=DBCon.getConnection();   
			  PreparedStatement pstmt=connection.prepareStatement("insert into assignissue values(?,?)"); 
			  
			  pstmt.setInt(1,rid1);  
			  pstmt.setString(2,pri);
			  pstmt.executeUpdate(); 
		        logger.info("Assigned issue successfully");
			  }
		  catch(Exception ex)  
		  { 
			  ex.printStackTrace(); 
			  logger.error("Unable to assign Issue");
		  }  
	}
}