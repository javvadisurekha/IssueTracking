package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.dbcon.DBCon;

@WebServlet("/AssignTicketServlet")
public class AssignTicketServlet extends HttpServlet 
{
	static final Logger logger = Logger.getLogger(AssignTicketServlet.class);
	static String prio;
	static int reportId;
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
	{
		 PropertyConfigurator.configure("G:\\sts workspace\\Issue Tracking System\\src\\log4j.properties");
	 		
        PrintWriter out = res.getWriter();
        res.setContentType("text/html");
        out.println("<html><body background=back.jpg>");
       
       try {
            Connection con = DBCon.getConnection();
            Statement stmt = con.createStatement();
            out.println("<h1 style=\"text:align=center\" style=\"color:white\">");
            out.println("Issues");
            out.println("</h1>");
            ResultSet rs = stmt.executeQuery("select * from issues");
            out.println("<table border=1 width=50% height=50% style=\"color:white\">");
            
            out.println("<tr><th>Report ID</th><th>Issue</th><th>Issue Category</th><th>Issue Description</th><th>Priority</th><th>Assign</th><tr>");
             while (rs.next()) 
            {
            	 out.println(" <form action=\"./Assign1\">");
            	 reportId = rs.getInt(1); 
                String isstitle = rs.getString(2);
                String isscat = rs.getString(3);
                String issdesc = rs.getString(4); 
                
                String isslink = " <input type=\"submit\" value=\"Assign\">";
                prio="<select name=priority>" + 
                		"                    <option value=\"\">Select</option>\r\n" + 
                		"					<option>1</option>\r\n" + 
                		"                     <option>2</option>\r\n" + 
                		"                     <option>3</option>\r\n" + 
                		"                     <option>4</option>\r\n" + 
                		"                     <option>5</option>\r\n" + 
                		"					</select>";
                out.println("<tr><td>" + reportId  + "</td><td>" + isstitle + "</td><td>" + isscat + "</td><td>" + issdesc+ "</td><td>"+ prio + "</td><td>"+ isslink +"</td></tr>");
                out.println("</form>");
            }
            out.println("</table>");
            out.println("<a href =\"admin.html\" > Mypage </a>");
            out.println("</body></html>");
            con.close();
           }
            catch (Exception e) {
              e.printStackTrace();
              logger.error("Assign Ticket Unsuccessfull");
        }
        }
}