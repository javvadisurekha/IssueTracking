package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.dbcon.DBCon;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	static final Logger logger = Logger.getLogger(RegisterServlet.class);
	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		 PropertyConfigurator.configure("G:\\sts workspace\\Issue Tracking System\\src\\log4j.properties");
	 		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		String utype=request.getParameter("utype").trim();
		String name=request.getParameter("name").trim();
		String  gender=request.getParameter("gender").trim();
		String dob=request.getParameter("dob").trim();
		String address=request.getParameter("address").trim();
		String pno=request.getParameter("pno").trim();
		String email=request.getParameter("email").trim();
		String  userid=request.getParameter("userid").trim();
		String password=request.getParameter("password").trim();
		
		try{
			Connection connection=DBCon.getConnection();
			Statement stmt=connection.createStatement();
			ResultSet rs=stmt.executeQuery("select userid from login where userid='"+userid+"' and type='"+utype+"' ");
			if(rs.next())
			{
				
				RequestDispatcher rd=request.getRequestDispatcher("reg.html");
				rd.include(request,response);
				

				out.println("<br><br><center><font color='red'>Userid Already Exists</font></center>");

			}
			else{
					PreparedStatement pstmt=connection.prepareStatement("insert into userreg values(?,?,?,?,?,?,?)");
					pstmt.setString(1,name);
					pstmt.setString(2,userid);
					pstmt.setString(3,gender);
					pstmt.setString(4,dob);
					pstmt.setString(5,address);
					pstmt.setString(6,pno);
					pstmt.setString(7,email);
					pstmt.executeUpdate();
					
					PreparedStatement pstmt1=connection.prepareStatement("insert into login values(?,?,?)");
					pstmt1.setString(1,userid);
					pstmt1.setString(2,password);
					pstmt1.setString(3,utype);
					pstmt1.executeUpdate();
					
					
					RequestDispatcher rd=request.getRequestDispatcher("index.html");
					rd.include(request,response);
					out.println("<br><center><font color='blue'>Registration Successful. You Can Login Now</center>");
					logger.info("Registered Successfully");
				}					
	   }catch(Exception ex){
			ex.printStackTrace();
			logger.error("Error while Registering");
			}	
	}
}