package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.dbcon.DBCon;

@WebServlet("/UpdateTicket")
public class UpdateTicket extends HttpServlet 
{
	static final Logger logger = Logger.getLogger(UpdateTicket.class);
	
	 static int repid;
	static String usname;
	static String isstitle;
	static String status;
	static String comment;
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{

		repid= ViewTicServlet.reportId;
		 isstitle= ViewTicServlet.isstitle;
		 status=request.getParameter("status").trim();
		comment=request.getParameter("address").trim();
	
		
		doPost(request, response);
		
		PrintWriter out = response.getWriter();
        response.setContentType("text/html");
        out.println("<html><body background=back.jpg>");
        out.println("<h1 style=\"text:align=center\">");
        out.println("Issue Resolved & Submitted Successfully");
        out.println("</h1>");
        out.println("<a href =\"systemEngineer.html\" > Mypage </a>");
        out.println("</body></html>");
       
	}
	@Override	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		resp.setContentType("text/html"); 
		int rid1 = repid;
		String title = isstitle;
		String stat = status;
		String comm = comment;
		
		 PropertyConfigurator.configure("G:\\sts workspace\\Issue Tracking System\\src\\log4j.properties");
		    logger.info("Update Ticket Successfully");
	 		
		  try{  
			  Connection connection=DBCon.getConnection();  
			  PreparedStatement pstmt=connection.prepareStatement("insert into issueupdates values(?,?,?,?)"); 
			  pstmt.setInt(1,rid1);  
			  pstmt.setString(2,title);
			  pstmt.setString(3,stat); 
			  pstmt.setString(4,comm);
			  pstmt.executeUpdate(); 
			  }
		  catch(Exception ex)  
		  { 
			  ex.printStackTrace(); 
			  logger.error("Error while updating");
		  }  
	}
}