package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.service.IssueService;

@WebServlet("/IssueServlet")
public class IssueServlet extends HttpServlet
	{
	static final Logger logger = Logger.getLogger(IssueServlet.class);
         @Override
         public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

        	 PropertyConfigurator.configure("G:\\sts workspace\\Issue Tracking System\\src\\log4j.properties");
 	 		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String title=request.getParameter("title").trim();
		String  category=request.getParameter("category").trim();
		String de=request.getParameter("de").trim();
		
		IssueService.getIssues(title,category,de);
				
		if(IssueService.status1>=0)
		{
		
    				RequestDispatcher rd= request.getRequestDispatcher("issue.html");
					rd.include(request,response);
					out.println("<br><br><br><center><font color='white'>Issue Submitted Successfully.</center>");
					logger.info("Raised Issue Successfully");
	    }
		else
		{
			out.println("<br><br><br><center><font color='white'>Unable to raise Issue.</center>");
			logger.error("Unable to raise Issue");
		}
}
	}