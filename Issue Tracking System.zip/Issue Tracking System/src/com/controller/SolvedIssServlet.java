package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.dbcon.DBCon;

@WebServlet("/SolvedIssServlet")
public class SolvedIssServlet extends HttpServlet 
{
	static final Logger logger = Logger.getLogger(SolvedIssServlet.class);
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		 PropertyConfigurator.configure("G:\\sts workspace\\Issue Tracking System\\src\\log4j.properties");
           logger.info("Viewing Updated Tickets");
	 		
		 PrintWriter out = response.getWriter();
	        response.setContentType("text/html");
	        out.println("<html><body background=back.jpg>");
	       
	        try {
	            Connection con = DBCon.getConnection();
	            Statement stmt = con.createStatement();
	            out.println("<h1 style=\"text:align=center\" style=\"color:white\">");
	            out.println("Issues");
	            out.println("</h1>");
	            ResultSet rs = stmt.executeQuery("select * from issueupdates");
	            out.println("<table border=1 width=50% height=50% style=\"color:white\">");
	            out.println("<tr><th>ReportID</th><th>Issue</th><th>Status</th><th>Comment</th><tr>");
	            while (rs.next()) 
	            {
	            	int rid = rs.getInt(1); 
	                String issuee = rs.getString(2);
	                String status = rs.getString(3);
	                String comment = rs.getString(4); 	                
	                out.println("<tr><td>" + rid  + "</td><td>" + issuee + "</td><td>" + status + "</td><td>" + comment +"</td></tr>");
	            }
	            out.println("</table>");
	            out.println("<a href =\"employee.html\" > Mypage </a>");
	            out.println("</body></html>");
	            con.close();
	           }
	            catch (Exception e) 
	        {
	              e.printStackTrace();
	          	logger.error("Error while Viewing Tickets");

	        }
	        }
}